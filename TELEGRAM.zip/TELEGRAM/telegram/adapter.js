"use strict";

/**
 * Telegram -> internal message adapter
 *
 * m = {
 *  chat, sender, pushName, text, isGroup,
 *  quoted, reply(), send(), sendPhoto()
 * }
 *
 * meta = { rawText, isCmd, command, args }
 */

const LEGACY_PREFIX_RE =
  /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\]/;

function parseCommand(rawText) {
  const text = (rawText || "").trim();
  if (!text) return { isCmd: false, command: null, args: [], rawText: "" };

  // Telegram command
  if (text.startsWith("/")) {
    // /cmd@botname args...
    const m = text.match(/^\/([a-zA-Z0-9_]+)(@\w+)?\s*(.*)$/);
    const command = (m?.[1] || "").toLowerCase();
    const rest = (m?.[3] || "").trim();
    const args = rest ? rest.split(/\s+/) : [];
    return { isCmd: true, command, args, rawText: text };
  }

  // Legacy prefix compat (.menu, !help, etc)
  const pref = text.match(LEGACY_PREFIX_RE)?.[0];
  if (pref) {
    const stripped = text.slice(pref.length).trim();
    const parts = stripped.split(/\s+/).filter(Boolean);
    const command = (parts[0] || "").toLowerCase();
    const args = parts.slice(1);
    return { isCmd: true, command, args, rawText: text };
  }

  return { isCmd: false, command: null, args: [], rawText: text };
}

function adaptTelegramMessage(ctx) {
  const chatId = String(ctx.chat?.id || "0");
  const from = ctx.from || {};
  const fromId = String(from.id || "0");
  const pushName =
    [from.first_name, from.last_name].filter(Boolean).join(" ") ||
    from.username ||
    "User";

  const rawText = String(
    (ctx.message && (ctx.message.text || ctx.message.caption)) || ""
  );

  const quoted = ctx.message?.reply_to_message
    ? {
        sender:
          String(ctx.message.reply_to_message.from?.id || "0") + "@telegram",
        text: String(
          ctx.message.reply_to_message.text ||
            ctx.message.reply_to_message.caption ||
            ""
        ),
      }
    : null;

  const isGroup =
    ctx.chat?.type === "group" ||
    ctx.chat?.type === "supergroup" ||
    ctx.chat?.type === "channel";

  const m = {
    chat: chatId,
    sender: `${fromId}@telegram`,
    pushName,
    text: rawText,
    isGroup,
    quoted,

    reply: async (text, extra) => ctx.reply(String(text), extra),
    send: async (text, extra) =>
      ctx.telegram.sendMessage(chatId, String(text), extra),
    sendPhoto: async (url, extra) =>
      ctx.telegram.sendPhoto(chatId, url, extra),
  };

  const meta = parseCommand(rawText);
  return { m, meta };
}

module.exports = { adaptTelegramMessage, parseCommand };