#THANKS TO
* pembuat base
* pembuat baileys 
* pembuat api
* yang sudah support 
* Allah 
* Ayah
* Ibu
* Teman
* Sahabat 