import TelegramBot from "node-telegram-bot-api";
import "dotenv/config";

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, {
  polling: true
});

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MODEL = "deepseek/deepseek-r1-0528:free";

async function askAI(prompt) {
  const res = await fetch(OPENROUTER_URL, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "http://localhost",
      "X-Title": "Telegram DeepSeek Bot"
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: "system", content: "Jawab sebagai asisten AI dalam bahasa Indonesia." },
        { role: "user", content: prompt }
      ],
      temperature: 0.6
    })
  });

  if (!res.ok) {
    throw new Error(await res.text());
  }

  const data = await res.json();
  return data.choices[0].message.content;
}

bot.on("message", async (msg) => {
  if (!msg.text || msg.text.startsWith("/")) return;

  const chatId = msg.chat.id;
  bot.sendChatAction(chatId, "typing");

  try {
    const reply = await askAI(msg.text);
    bot.sendMessage(chatId, reply.slice(0, 4000));
  } catch (e) {
    bot.sendMessage(chatId, "❌ Model sedang penuh atau error. Coba lagi nanti.");
    console.error(e.message);
  }
});

console.log("🤖 Bot Telegram DeepSeek jalan...");